from django.urls import path
from . import views

urlpatterns = [
<<<<<<< HEAD
    path('', views.index)
=======
    path('', views.auth),
>>>>>>> first commit
]
