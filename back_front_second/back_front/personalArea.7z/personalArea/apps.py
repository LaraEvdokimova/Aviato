from django.apps import AppConfig


class PersonalareaConfig(AppConfig):
    name = 'personalArea'
