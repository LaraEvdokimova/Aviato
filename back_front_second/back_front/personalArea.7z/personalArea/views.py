from django.shortcuts import render

<<<<<<< HEAD
def index(req):
    return render(req, 'input/index.html')
=======

def auth(req):
    return render(req, 'input/auth.html')
>>>>>>> first commit
